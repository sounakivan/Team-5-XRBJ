# Changelog

All notable changes to this project that are not part of the original repository.
[Github Repository Link](https://github.com/keijiro/jp.keijiro.apriltag)

- addition of other AprilTag familys